﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projekat.Controllers
{
    public class AdministratorController : Controller
    {
        // GET: Administrator
        public ActionResult Index() //njegov index, odmah se prikazuje i prikazuje sve korisnike 
            //dobave se svi useri iz baze  i posalju se pomocu onog modela .tolist i sa foreach sa view ih prikaze,
            //--tamo objasnjenje, na admin view 
        {
            var korisnici = TxtHelper.GetAllUsers(false);
            return View("AdministratorView", korisnici.ToList());
        }

        // GET: Administrator
        public ActionResult VozilaPrikaz() //ide na layaou adminview
        {
            var vozila = TxtHelper.GetAllCars(true); //dolazi se sa adminviewlayout , uzima sva auta , proseldice tamo u view 
            //kao model i tamom da ih priakze sve 
            return View("VozilaView", vozila.ToList()); //idemo na vozila view
        }

        public ActionResult DodajVoziloPrikaz()
        {
            return View("DodavanjeVozilaView");
        }


        [HttpPost]

        public ActionResult ObrisiKorisnika(string btn) //prosledimo name od onog sto smo kliknuli , button, on ce da ima vrenost 
            //korisnicko ime npr sarajovic i to se
          //  proslednjuje kao parametar u adminview value.korisnik.korisnickoime
        {
            string korisnickoIme = btn;

            TxtHelper.DeleteUser(korisnickoIme);

            return RedirectToAction("Index"); //opet ide na akciju i prikazuje sve
        }

        [HttpGet]

        public ActionResult ModifikujVoziloPrikaz(string btn) //bice vrednosst id od vozila parsira ga i prosledi getcar by id, 
            //on ga prikaze
        {
            int id = Int32.Parse(btn);

            Models.Vozilo vozilo = TxtHelper.GetCarById(id);

            return View("ModifikujVoziloView", vozilo);
        }

        [HttpPost]

        public ActionResult ModifikujVozilo(string btn) // , ima modif, opet ide njegov id, pokupi sve vredonsti sa request form

        {
            string marka = Request.Form["marka"]; //value je "marka"
            string model = Request.Form["model"];
            string sasija = Request.Form["sasija"];
            string boja = Request.Form["boja"];
            string opis = Request.Form["opis"];
            string naStanju = Request.Form["nastanju"];
            // onda modifikuje, 
            //ovo su validacije
            //na istu foru je i dodaj vozilo..
            //posle idemo na registrovankorisnik
            ViewBag.Nazad = "/Administrator/VozilaPrikaz";

            if (sasija == ""  || marka == "" || model == "" || boja == "")
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";

                return View("ErrorView");
            }

            //to je dodato kao da li je na isti model na stanju, npr da li od nekog modela ima 5 istih auta 
            //

            bool stanje = false;

            if (naStanju == "1")
            {
                stanje = true;
            }

            float cena;
            if (!float.TryParse(Request.Form["cena"], out cena))
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            if (cena < 0)
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            int brVrata;
            if (!Int32.TryParse(Request.Form["vrata"], out brVrata))
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            if (brVrata < 0)
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            Enums.VrstaGoriva gorivo = Enums.VrstaGoriva.Benzin;

            switch (Int32.Parse(Request.Form["goriva"]))
            {
                case 0:
                    gorivo = Enums.VrstaGoriva.Dizel;
                    break;
                case 1:
                    gorivo = Enums.VrstaGoriva.Benzin;
                    break;
                case 2:
                    gorivo = Enums.VrstaGoriva.Gas;
                    break;
                case 3:
                    gorivo = Enums.VrstaGoriva.BenzinGas;
                    break;
                case 4:
                    gorivo = Enums.VrstaGoriva.Metan;
                    break;
                case 5:
                    gorivo = Enums.VrstaGoriva.Elektricni;
                    break;
                case 6:
                    gorivo = Enums.VrstaGoriva.Hibridni;
                    break;

                default:
                    break;
            }

            //enum

            TxtHelper.ModifieCar(Int32.Parse(btn),marka,model, sasija, boja, brVrata, opis, gorivo, cena, stanje, false);

            return RedirectToAction("VozilaPrikaz");
        }

        [HttpPost]

        public ActionResult DodajVozilo()
        {
            int opcija = Int32.Parse(Request.Form["goriva"]);
            string model = Request.Form["model"];
            string marka = Request.Form["marka"];
            string sasija = Request.Form["sasija"];
            string boja = Request.Form["boja"];
            int vrata;
            float cena;
            ViewBag.Nazad = "/Administrator/DodajVoziloPrikaz";

            if (!Int32.TryParse(Request.Form["vrata"], out vrata) || !float.TryParse(Request.Form["cena"], out cena))
            {
                ViewBag.ErrorMessage = "Neuspesno dodavanje!";
                return View("ErrorView");
            }
            string opis = Request.Form["opis"];


            if (sasija == "" || marka == "" || model == "" || boja == "")
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            if (vrata < 0 || cena < 0)
            {
                ViewBag.ErrorMessage = "Neuspesno modifikovanje!";
                return View("ErrorView");
            }

            Enums.VrstaGoriva gorivo = Enums.VrstaGoriva.Benzin;

            switch (Int32.Parse(Request.Form["goriva"]))
            {
                case 0:
                    gorivo = Enums.VrstaGoriva.Dizel;
                    break;
                case 1:
                    gorivo = Enums.VrstaGoriva.Benzin;
                    break;
                case 2:
                    gorivo = Enums.VrstaGoriva.Gas;
                    break;
                case 3:
                    gorivo = Enums.VrstaGoriva.BenzinGas;
                    break;
                case 4:
                    gorivo = Enums.VrstaGoriva.Metan;
                    break;
                case 5:
                    gorivo = Enums.VrstaGoriva.Elektricni;
                    break;
                case 6:
                    gorivo = Enums.VrstaGoriva.Hibridni;
                    break;

                default:
                    break;
            }

            TxtHelper.AddCar(marka, model, sasija, boja, vrata, opis, gorivo, cena);

            return RedirectToAction("VozilaPrikaz");
        }

    }
}