﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projekat.Controllers
{
    public class RegistrovanKorisnikController : Controller
    {
        // GET: RegistrovanKorisnik
        public ActionResult Index(string sort, string searchBy, string markasearch, string modelsearch, string odcena, string docena)
        {
            //opet sort, src kao pocetni kad nisu registorvani
            var vozila = TxtHelper.GetAllCars(false);

            if (!String.IsNullOrEmpty(sort))
            {
                switch (sort)
                {
                    case "markaopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Marka).ToList();
                        break;
                    case "markarastuci":
                        vozila = vozila.OrderBy(s => s.Marka).ToList();
                        break;
                    case "modelopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Model).ToList();
                        break;
                    case "modelrastuci":
                        vozila = vozila.OrderBy(s => s.Model).ToList();
                        break;

                    case "cenaopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Cena).ToList();
                        break;
                    case "cenarasteci":
                        vozila = vozila.OrderBy(s => s.Cena).ToList();
                        break;

                    default:
                        vozila = vozila.OrderBy(s => s.Cena).ToList();
                        break;
                }
            }
            if (!String.IsNullOrEmpty(searchBy))
            {
                switch (searchBy)
                {
                    case "marka":
                        if (String.IsNullOrEmpty(markasearch))
                        {
                            break;
                        }
                        vozila = vozila.Where(s => s.Marka.ToUpper().Contains(markasearch.ToUpper())).ToList();
                        break;
                    case "model":
                        if (String.IsNullOrEmpty(modelsearch))
                        {
                            break;
                        }
                        vozila = vozila.Where(s => s.Model.ToUpper().Contains(modelsearch.ToUpper())).ToList();
                        break;
                    case "cena":
                        if (String.IsNullOrEmpty(odcena) && String.IsNullOrEmpty(docena))
                        {
                            break;
                        }
                        else if (!String.IsNullOrEmpty(odcena) && String.IsNullOrEmpty(docena))
                        {
                            vozila = vozila.Where(s => s.Cena >= float.Parse(odcena)).ToList();
                        }
                        else if (!String.IsNullOrEmpty(docena) && String.IsNullOrEmpty(odcena))
                        {
                            vozila = vozila.Where(s => s.Cena <= float.Parse(docena)).ToList();
                        }
                        else
                        {
                            vozila = vozila.Where(s => s.Cena <= float.Parse(docena) && s.Cena >= float.Parse(odcena)).ToList();
                        }

                        break;
                    default:
                        break;
                }
            }
            ViewBag.PrikazKupovina = false ;

            return View("RegistrovanKorisnikView", vozila.ToList());
        }

        public ActionResult Detaljnije(string btn)
            //od admina uzeto  pronadje vozilo, posalje ga kao model i tamo ga samo uzme i prikaze njegove detalje
            //ima opcija da se kupi i to opet preko id vozila i tako zna koji je vozilo
        {
            ViewBag.PrikazKupovina = true;
            ViewBag.AutoId = Int32.Parse(btn);
            var vozila = TxtHelper.GetAllCars(false);
            var car = vozila.Find(x=>x.Id == ViewBag.AutoId);
            return View("DetaljiVozilaView", car);
        }

        public ActionResult PrikazKupovina()
        {
            //session -
            //kad se neko logovo uspesno, nakon togaubacimo tog korisnika u sesiju (logcontroller)
            //ako zatreba id od ovog sto se ulogovao , cuvali smo ga u sesiju, iz sesije  pokupimo to korisniko ime koje je 
            //ulogovano i idemo na metodu koja na osnovu id kupi sve kupovine
            var kupovine = TxtHelper.GetAllPurchasesOfUser(Session["username"].ToString());
            ViewBag.PrikazKupovina = true;

            return View("KupovineView", kupovine); //ovo nije ni koristeno 
        }

        [HttpPost]
        public ActionResult Kupovina()
        {

            if (TxtHelper.BuyCar(Session["username"].ToString(), Int32.Parse(Request.Form["btn"])))
            {
                return RedirectToAction("Index");
            }

            ViewBag.ErrorMessage = "Neuspesna kupovina";
            ViewBag.Nazad = "/RegistrovanKorisnik";

            return View("ErrorView");
        }

        
    }
}