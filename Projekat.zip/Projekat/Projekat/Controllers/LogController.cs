﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projekat.Controllers
{
    public class LogController : Controller
    {
        // GET: Log
        public ActionResult Index() // dolazimo ovde sa pocetnaview 
            //ide na svoj view 
        {
            return View("Login");
        }

        [HttpPost]
        public ActionResult LogIn()
        {                                           //request.form prikupi iz forme name, moglo je i preko parametara korisnicko ime
            Models.Korisnik korisnik = TxtHelper.Login(Request.Form["korisnickoime"], Request.Form["lozinka"]);

            ViewBag.Nazad = "/Log";

            if (korisnik == null)
            {
                ViewBag.ErrorMessage = "Korisnicko ime ili lozinka nisu ispravni!";
                return View("ErrorView");
            }

            //u zavisnosti od uloge rediktuje na index od administratora
            Session["username"] = korisnik.KorisnickoIme;
            //sesija radjena na registrovankorisnik 
            //kad se uspesno uloguje , nakon toga tog korisnika unesemo u sesiju, tj,njegovo korisnicko ime
            //i onda sve vreme dok je aplikaciju upaljena moci da se iz sesije  zna pomocu "userneme" koje je korisnicko ime trenutno aktivno 
            //VIEWBAG JE IZMEDJU STRANICE, TIPA SA JEDNE STARANE NA DTRUGU I TO SE BRISE, 
            //UMESTO SESIE MOGAO I CACHE , U SESIJI NAM SE U POLJU USERNAME KOJI JE KLJUC CUVACE SE AKTIVAN KORISNIK

            if (korisnik.Uloga == Enums.UlogaKorisnika.Administrator)
            {
                return RedirectToAction("Index", "Administrator");

            }
            //ili redirektuje na index reg.korisnika 
            return RedirectToAction("Index", "RegistrovanKorisnik");
        }
    }
}