﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projekat.Controllers
{
    public class PocetnaController : Controller
    {
        //ako nema npr [http get] 
        // route("indexstrana")
        //ili https localhost:5000/pocetnastrana/index
        // GET: Pocetna

            //sto se tice indexa ima parametre, i on te parametre kupi sa VIEW -, idemo na pocetnaview na 157 liniju, imamo
       //2 batona
            //on ce da pogodi pocetna controller
            //
        public ActionResult Index(string sort, string searchBy, string markasearch, string modelsearch, string odcena, string docena)
        {
            // i mora da se zove isto u pocetnacontorller : actionresult index()sort, search...
          //  i on ce imati vrednost value, a value unosimo mi npr mercedes
            //i on ce u pocetna controller imati tu vrenost ostali parametri ce biti null
            
         var vozila = TxtHelper.GetAllCars(false); //iz txthelpera uzima getallcar -> txthelper 108.
            //da pokupi sva auta

            if (!String.IsNullOrEmpty(sort)) //provera za sort
            {
                switch (sort)
                {
                    case "markaopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Marka).ToList();
                        break;
                    case "markarastuci":
                        vozila = vozila.OrderBy(s => s.Marka).ToList();
                        break;
                    case "modelopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Model).ToList();
                        break;
                    case "modelrastuci":
                        vozila = vozila.OrderBy(s => s.Model).ToList();
                        break;

                    case "cenaopadajuci":
                        vozila = vozila.OrderByDescending(s => s.Cena).ToList();
                        break;
                    case "cenarasteci":
                        vozila = vozila.OrderBy(s => s.Cena).ToList();
                        break;

                    default:
                        vozila = vozila.OrderBy(s => s.Cena).ToList();
                        break;
                }
            }
            if (!String.IsNullOrEmpty(searchBy)) //provera za search
                
            {
                switch (searchBy) //searchby trazi name u pocetnaview, name=seachby, value=marka
                    //objasnjeneje na pocetnaview
                {
                    case "marka":
                        if (String.IsNullOrEmpty(markasearch))
                        {
                            break; //zbog gresaka
                        }
                        vozila = vozila.Where(s => s.Marka.ToUpper().Contains(markasearch.ToUpper())).ToList();
                        //kupi sva vozila, pretvori u velika sloba , i vratice vozila koja su npr mercedes
                        //isto i za ostali search i sort
                        break;
                    case "model":
                        if (String.IsNullOrEmpty(modelsearch))
                        {
                            break;
                        }
                        vozila = vozila.Where(s => s.Model.ToUpper().Contains(modelsearch.ToUpper())).ToList();
                        break;
                    case "cena":
                        if (String.IsNullOrEmpty(odcena) && String.IsNullOrEmpty(docena))
                        {
                            break;
                        }
                        else if (!String.IsNullOrEmpty(odcena) && String.IsNullOrEmpty(docena))
                        {
                            vozila = vozila.Where(s => s.Cena >= float.Parse(odcena)).ToList();
                        }
                        else if (!String.IsNullOrEmpty(docena) && String.IsNullOrEmpty(odcena))
                        {
                            vozila = vozila.Where(s => s.Cena <= float.Parse(docena)).ToList();
                        }
                        else
                        {
                            vozila = vozila.Where(s => s.Cena <= float.Parse(docena) && s.Cena >= float.Parse(odcena)).ToList();
                        }

                        break;
                    default:
                        break;
                }
            }

            //kad sve odradi ide na view pocetnaview i prosledi mu se parametar vozila.tolist
            //pocetnaview na pocetku sa @ - pbjasnjenje 
            return View("PocetnaView", vozila.ToList());
        }

        public ActionResult Kupovina()
            //194.linija u pocetnaview
            //
        {
            return RedirectToAction("Index", "Log"); //indeks je ime akcije, a log ime kontrolera , 
            //i ide na Logcontroller i njegovu indeks akciju
        }
    }
}