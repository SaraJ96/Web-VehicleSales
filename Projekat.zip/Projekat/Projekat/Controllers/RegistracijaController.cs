﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projekat.Controllers
{
    public class RegistracijaController : Controller
    {
        //slicno kao pocetnakontroleer
        //tu su validacije sve, do kraja skoro, do poslednje metode adduser
        [HttpGet]
        public ActionResult Index()
        {
            return View("Registracija");
        }

        [HttpPost]
        public ActionResult RegistracijaKorisnika()
        {
            DateTime datumRodjenja;
            try
            {
                string DatecorrectFormat = DateTime.ParseExact(Request.Form["datum"], "yyyy-MM-dd", null).ToString("dd/MM/yyyy");
                datumRodjenja = DateTime.ParseExact(DatecorrectFormat, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch (Exception)
            {
                ViewBag.ErrorMessage = "Pogresno unet datum!";
                ViewBag.Nazad = "/Registracija";
                return View("ErrorView");
            }


            if (String.IsNullOrWhiteSpace(Request.Form["korime"]) || String.IsNullOrWhiteSpace(Request.Form["ime"]) ||
                String.IsNullOrWhiteSpace(Request.Form["prezime"]) ||
                String.IsNullOrWhiteSpace(Request.Form["lozinka"])||
                String.IsNullOrWhiteSpace(Request.Form["potvrda"]) ||
                String.IsNullOrWhiteSpace(Request.Form["pol"]) ||
                String.IsNullOrWhiteSpace(Request.Form["email"]))
            {
                ViewBag.ErrorMessage = "Popunite sva polja!";
                ViewBag.Nazad = "/Registracija";

                return View("ErrorView");
            }

            if (Request.Form["lozinka"].Length < 8)
            {
                ViewBag.ErrorMessage = "Lozinka mora da ima bar 8 karaktera!";
                ViewBag.Nazad = "/Registracija";

                return View("ErrorView");
            }

            if (Request.Form["lozinka"] != Request.Form["potvrda"])
            {
                ViewBag.ErrorMessage = "Lozinke se ne poklapaju!";
                ViewBag.Nazad = "/Registracija";

                return View("ErrorView");
            }


            //ako je uspesno znaci da ga je uspesno ubacio, ako nije greska
            //ako je uspesno redirektuje ga na log na njegov indeks  i to je onaj prozor da za log
            bool uspesno = TxtHelper.AddUser(Request.Form["korime"], Request.Form["ime"], Request.Form["prezime"], Request.Form["lozinka"],
               datumRodjenja, Request.Form["pol"], Request.Form["email"]);

            if (uspesno)
            {
                return RedirectToAction("Index", "Log");
            }

            ViewBag.ErrorMessage = "Korisnicko ime vec postoji!";
            ViewBag.Nazad = "/Registracija";

            return View("ErrorView"); //ako je neuspesno ide na eeror view
            //pomogu view baga prima error message
            //tu se sa nazad vraca na prethodnu stranu, odnosno na prozor za registraciju,
            //kad je ime kontrolera bez index: /registracija - ide sam na index 
        }
    }
}