﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Projekat
{
    public class TxtHelper
    {
        private static string path = @"C:\Users\Sara\Desktop\Projekat\Projekat"; 
        private static string DbKorisniciPath = path + "\\DataBase\\KorisniciDb.txt";
        private static string DbVozilaPath = path + "\\DataBase\\VozilaDb.txt";
        private static string DbKupovinaPath = path + "\\DataBase\\KupovineDb.txt";

        public static List<Models.Korisnik> GetAllUsers(bool saAdminima) //lista prcita sa readtxt svaku liniju  i
            //samo joj prosledimo pitanju 
        {
            List<Models.Korisnik> allUsers = new List<Models.Korisnik>();

            List<string> lines = ReadTxt(DbKorisniciPath);

            foreach (var line in lines)
            { // pokupi sve usere ... dzejson serilizacija
                //kad ide iz objekta u liniju serilizacija
                //iz linije u objekat deserilizacija
                Models.Korisnik korisnik = JsonConvert.DeserializeObject<Models.Korisnik>(line);
                        //ako je korisnik obrisan continue, i da nije admin,
                if (korisnik.Uloga == Enums.UlogaKorisnika.Administrator && !saAdminima || korisnik.Obrisan)
                    continue;
                //kad je admin preskacecont i ubacuje kosinika 
                allUsers.Add(korisnik);
            }
            //uglavnom obrisane oreskace
            return allUsers;
        }

        public static bool AddUser(string korisnickoime, string ime, string prezime, string lozinka, DateTime datumRodjenja, string pol, string email)
        {
            if (UserExists(korisnickoime))
            {
                return false;
            }
            //dodaje usere
            Models.Korisnik noviKorisnik = new Models.Korisnik(korisnickoime, lozinka, ime, prezime, email, datumRodjenja, pol);

            WriteSingleLineToTxt(JsonConvert.SerializeObject(noviKorisnik), DbKorisniciPath);
            return true;
        }

        //ova metoda porverava da li korisnik postoji , find ce da vrati ako nadje nekoga sa tim uslovom ,
        //ako ga ne vati ostace null, ako nije null true, a ako je null vraca folse...
        //wsl dodaje, nalepi jos jednu liniju
        public static bool UserExists(string korisnickoime)
        {
            List<Models.Korisnik> allUsers = GetAllUsers(true);
            Models.Korisnik korisnik = allUsers.Find(user => user.KorisnickoIme == korisnickoime);

            if (korisnik != null)
            {
                return true;
            }

            return false;
        }

        //samo vraca usera tako da mu vazi uslov s tim da nije obrisan, ne vraca obrisane usere
        public static Models.Korisnik GetUserByUsrName(string username)
        {
            List<Models.Korisnik> allUsers = GetAllUsers(true);
            Models.Korisnik korisnik = allUsers.Find(x => x.KorisnickoIme == username && !x.Obrisan);

            return korisnik;
        }

        //find gde je kime = onom sto smoprosledili i lozinka , ako je nesto pogresno nece se moci logovati, ako nije null proci ce
        public static Models.Korisnik Login(string korisnickoime, string lozinka)
        {
            List<Models.Korisnik> allUsers = GetAllUsers(true);
            Models.Korisnik korisnik = allUsers.Find(user => user.KorisnickoIme == korisnickoime && user.Lozinka == lozinka);

            return korisnik;
        }

        public static void DeleteUser(string username)
        {
            //ako ne postoji ne mozemo ga obrisati, 
            if (!UserExists(username))
            {
                return;
            }

            List<Models.Korisnik> allUsers = GetAllUsers(true); //true je jer treba uhvatiti sve usere
            // ovde su svi useri, mora da se stavi indeks bas od tog usera da bi nesto uspeli kod njega da promenimo
            //ne moze da ga izdvojimo pa da menjamo pa vratimo, 
            //i zato njegov find indeks korisnicko = tog kog smo proslediti
            //i onda obrise sve i ponovo ih ispise 
            allUsers[allUsers.FindIndex(x => x.KorisnickoIme == username)].Obrisan = true;

            WriteAllUsersToTxt(allUsers);
        }

        public static void WriteAllUsersToTxt(List<Models.Korisnik> users)
        {
            List<string> lines = new List<string>();

            foreach (var user in users)
            {
                lines.Add(JsonConvert.SerializeObject(user));
            }

            WriteMultipleLinesToTxt(lines, DbKorisniciPath);
        }

        #region Vozila
         //isto ka o get all user
        public static List<Models.Vozilo> GetAllCars(bool admin)
        { //pocetna controllers
            //bool admin ako je admin da moze da vidi i ona koja su kupljena, a ako nije admin da ne vidi sva 
            List<string> lines = ReadTxt(DbVozilaPath); //
            List<Models.Vozilo> allCars = new List<Models.Vozilo>();

            foreach (var line in lines)
            {
                var car = JsonConvert.DeserializeObject<Models.Vozilo>(line);

                if (car.Kupljen && !admin) //ako nisi admin i ako je kupljen ne prikazuje, ako admin prikazuje sve i user name onog ko je kupio 
                {
                    continue;
                }

                allCars.Add(car);
            }

            return allCars;
        }

        public static Models.Vozilo GetCarById(int id)
        {
            return GetAllCars(true).Find( x => x.Id == id); 
        }
        //isto kao add usee
        public static bool AddCar(string marka, string model, string sasija, string boja, int vrata, string opis, Enums.VrstaGoriva gorivo, float cena)
        {
            try
            {
                //sto se tice id car doda mu se count tipa ako imamo 5 indeks novog ce biti 5
                Models.Vozilo car = new Models.Vozilo(marka, model, sasija, boja, vrata, opis, gorivo, cena);
                car.Id = GetAllCars(true).Count;

                WriteSingleLineToTxt(JsonConvert.SerializeObject(car), DbVozilaPath);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        //isto kao brisanje
        //prosledimo mu sve sto se menjalo,
        public static bool ModifieCar(int id, string marka, string model, string sasija, string boja, int vrata, string opis, Enums.VrstaGoriva gorivo,
            float cena, bool naStanju, bool kupljen)
        {
            try
            { //nadjeno taj auto sa idem koji smo proslediti
                List<Models.Vozilo> allcars = GetAllCars(true);
                Models.Vozilo car = allcars.Find(x => x.Id == id);
                //ako je kupljen  ne mozemo ga modifikovati
                if (car.Kupljen)
                {
                    return false;
                }

                //ako nije kupljen modifiku 
                car.Marka = marka;
                car.Model = model;
                car.OznakaSasije = sasija;
                car.BrojVrata = vrata;
                car.Opis = opis;
                car.VrstaGoriva = gorivo;
                car.Cena = cena;
                car.Boja = boja;
                car.Kupljen = kupljen;
                car.NaStanju = naStanju; 

                //dodamo car i na to mesto gde je bio ce opet biti samo modifikovan
                allcars[car.Id] = car;

                List<string> lines = new List<string>();

                foreach (var c in allcars)
                {
                    lines.Add(JsonConvert.SerializeObject(c));
                }

                WriteMultipleLinesToTxt(lines, DbVozilaPath);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion


        #region Kupovina

        //prosledimo car id, pokupe se sve kupovine iz baze kupovina i pronalaze se, za dmina, da se prikaze ko je kupac
        //nadje za svako auto ako je njegov id vraca se njegov id, 
        //ako nije kupljen, nece ni uci nikad u to, jedino ako posalje neki car id kog nema al nije to npravljeno
        public static string GetBuyerUsername(int carId)
        {
            var allPurchases = GetAllPurchases();

            foreach (var item in allPurchases)
            {
                if (item.Vozilo.Id == carId)
                {
                    return item.Korisnik.KorisnickoIme;
                }
            }

            return "Nema";
        }

        //prikaz svih kupovina
        public static List<Models.Kupovina> GetAllPurchases()
        {
            List<string> lines = ReadTxt(DbKupovinaPath);
            List<Models.Kupovina> all = new List<Models.Kupovina>();

            foreach (var line in lines)
            {
                all.Add(JsonConvert.DeserializeObject<Models.Kupovina>(line));
            }

            return all;
        }

        //posaljes username i car id koji se kupouje, dobavi se oba ta
        //provera da li je kupljen, dal i je na stanju, da l je razlicit od null
        //
        public static bool BuyCar(string username, int carId)
        {
            var car = GetCarById(carId);
            var user = GetUserByUsrName(username);

            if (user != null &&  car != null && !car.Kupljen && car.NaStanju)
            {
                //nova metoda koja odradi metodu koja je vec napravljena 
                //da bi je pretovrio da je taj auto kupljen, da bi dodao kao da je kupljen
                ModifieCar(car.Id, car.Marka, car.Model, car.OznakaSasije, car.Boja, car.BrojVrata, car.Opis, car.VrstaGoriva, car.Cena, car.NaStanju, true);

                //kupovina objekat i zapise se u bazu kupovine
                Models.Kupovina purchase = new Models.Kupovina(user, car, DateTime.Now, car.Cena);
                //akoj e uspesna upis
                WriteSingleLineToTxt(JsonConvert.SerializeObject(purchase), DbKupovinaPath);

                return true;
             }
            return false;
        }

        //da pokupi sve kupovina od usera po usernameu 
        //
        public static List<Models.Kupovina> GetAllPurchasesOfUser(string username)
        {
            if (!UserExists(username))
            {
                return null; //provera
            }

            //kupi sve njegove kupovine, deserijalizuje i vraca nazad kod usera koji je logovan, upisuje u bazu 
            List<Models.Kupovina> allPurchases = new List<Models.Kupovina>();

            var purchases = ReadTxt(DbKupovinaPath);

            foreach (var line in purchases)
            {
                var purchase = JsonConvert.DeserializeObject<Models.Kupovina>(line);

                if (purchase.Korisnik.KorisnickoIme == username)
                {
                    allPurchases.Add(purchase);
                }
            }

            return allPurchases;
        }
        #endregion

        //kad modifikujemo nesto jednu liniju, moramo da obrisemo sve, izmenimo, pa ponovo sve upisemo to izmenjeno
        public static void WriteMultipleLinesToTxt(List<string> lines, string path)
        {

            File.WriteAllText(path, String.Empty);

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(path))
            {
                foreach (string line in lines)
                {
                    file.WriteLine(line);
                }
            }
        }

        //kad dodajemo singleline i on ce samo u sledeci slobodan red da upise 
        public static void WriteSingleLineToTxt(string line, string path)
        {
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(path, true))
                        {
                            file.WriteLine(line);
                        }
        }

        public static List<string> ReadTxt(string path) //pokupi sve linije redom i pretvori u listu i vraca nazad
        {
            List<string> lines = System.IO.File.ReadAllLines(path).ToList();

            return lines;
        }

    }
}