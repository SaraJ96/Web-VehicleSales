﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Projekat.Models
{
    public class Korisnik
    {
        public Korisnik(string korisnickoIme, string lozinka, string ime, string prezime, string email, DateTime datumRodjenja, string pol)
        {
            KorisnickoIme = korisnickoIme;
            Lozinka = lozinka;
            Ime = ime;
            Prezime = prezime;
            Email = email;
            DatumRodjenja = datumRodjenja;
            Uloga = Enums.UlogaKorisnika.Kupac;
            Pol = pol;
            Obrisan = false;
        }

        [StringLength(30, MinimumLength = 3, ErrorMessage = "Minimum 3 characters")]
        public string KorisnickoIme { get; set; }

        [StringLength(30, MinimumLength = 8, ErrorMessage = "Minimum 8 characters")]
        public string Lozinka { get; set; }

        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Email { get; set; }
        public string Pol { get; set; }
        public DateTime DatumRodjenja { get; set; }
        public Enums.UlogaKorisnika Uloga { get; set; }

        public bool Obrisan { get; set; }

      

      
    }
}