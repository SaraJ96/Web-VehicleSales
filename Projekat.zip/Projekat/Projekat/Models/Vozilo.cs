﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Projekat.Enums;

namespace Projekat.Models
{
    public class Vozilo
    {

        public Vozilo(string marka, string model, string oznakaSasije, string boja, int brojVrata, string opis, VrstaGoriva vrstaGoriva, float cena)
        {
            Marka = marka;
            Model = model;
            OznakaSasije = oznakaSasije;
            Boja = boja;
            BrojVrata = brojVrata;
            Opis = opis;
            VrstaGoriva = vrstaGoriva;
            Cena = cena;
            NaStanju = true;
            Kupljen = false;
        }

        [StringLength(30, MinimumLength = 3, ErrorMessage = "Minimum 3 characters")]
        public string Marka { get; set; }
        public string Model { get; set; }
        public string OznakaSasije { get; set; }
        public string Boja { get; set; }
        public int BrojVrata { get; set; }
        public string Opis { get; set; }
        public Enums.VrstaGoriva VrstaGoriva { get; set; }
        public float Cena { get; set; }
        public bool NaStanju { get; set; }

        public int Id { get; set; }
        public bool Kupljen { get; set; }

    }
}