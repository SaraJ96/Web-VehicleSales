﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Projekat.Enums;

namespace Projekat.Models
{
    public class Kupovina
    {

        public Kupovina(Korisnik korisnik, Vozilo vozilo, DateTime datumKupovine, float naplacenaCena)
        {
            Korisnik = korisnik;
            Vozilo = vozilo;
            DatumKupovine = datumKupovine;
            NaplacenaCena = naplacenaCena;
        }


        public Korisnik Korisnik { get; set; }
        public Vozilo Vozilo { get; set; }
        public DateTime DatumKupovine { get; set; }
        public float NaplacenaCena { get; set; }

    }
}