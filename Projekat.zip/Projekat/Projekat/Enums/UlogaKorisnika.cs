﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projekat.Enums
{
    public enum UlogaKorisnika
    {
        Administrator,
        Kupac
    }
}